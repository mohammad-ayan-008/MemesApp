package com.example.memehouse;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.http.GET;

public interface apicall {
    @GET("/gimme/10")
    Call<MemesFetch> getMemes();
}
